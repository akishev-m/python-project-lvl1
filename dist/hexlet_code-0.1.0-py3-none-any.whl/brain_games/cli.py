#!/usr/bin/env python

import scripts.brain_games


def main():
    print("Welcome to the Brain Games!")
    scripts.brain_games.welcome_user()
   
#    print(sys.path)

if __name__ == '__main__':
    main()
#    brain_games.welcome_user()


