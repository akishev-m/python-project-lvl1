
NAME = 'scripts'
